package com.api.ady.pdfGenerator;

import com.api.ady.cliente.Cliente;

public interface ClientService {
    Cliente getClienteById(Long id); 
}


